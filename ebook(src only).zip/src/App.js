import React from 'react';

import BasicRoute from './AppRouter'
import './App.css';

class App extends React.Component {


  render() {
    return (
        <BasicRoute/>
    );
  }
}

export default App;
