import Form from 'antd/lib/form/Form';
import React from 'react'

class LoginForm extends React.Component {
    render() {
        return (
            <Form>
                
            </Form>
        )
    }
}

export default LoginForm;