// import React from 'react';
// import { Table, Input, InputNumber, Popconfirm, Form, Typography } from 'antd';
// const originData = [];

// for (let i = 0; i < 100; i++) {
//     originData.push({
//         key: i.toString(),
//         name: `Edrward ${i}`,
//         age: 32,
//         address: `London Park no. ${i}`,
//     });
// }

// const EditableCell = ({
//     editing,
//     dataIndex,
//     title,
//     inputType,
//     record,
//     index,
//     children,
//     ...restProps
// }) => {
//     const inputNode = inputType === 'number' ? <InputNumber /> : <Input />;
//     return (
//         <td {...restProps}>
//             {editing ? (
//                 <Form.Item
//                     name={dataIndex}
//                     style={{
//                         margin: 0,
//                     }}
//                     rules={[
//                         {
//                             required: true,
//                             message: `Please Input ${title}!`,
//                         },
//                     ]}
//                 >
//                     {inputNode}
//                 </Form.Item>
//             ) : (
//                 children
//             )}
//         </td>
//     );
// };

// const form = Form.useForm();
// class EditableTable extends React.Component {

//     state = {
//         data: originData,
//         editingKey: '',
//     }

//     isEditing = (record) => record.key === this.state.editingKey;

//     edit = (record) => {
//         form.setFieldsValue({
//             name: '',
//             age: '',
//             address: '',
//             ...record,
//         });
//         this.setState(
//             { editingKey: record.key }
//         );
//     };

//     cancel = () => {
//         this.setState(
//             { editingKey: '' }
//         )
//     };

//     save = async (key) => {
//         try {
//             const row = await form.validateFields();
//             const newData = [...this.state.data];
//             const index = newData.findIndex((item) => key === item.key);

//             if (index > -1) {
//                 const item = newData[index];
//                 newData.splice(index, 1, { ...item, ...row });
//                 this.setState(
//                     {
//                         data: newData,
//                         editingKey: ''
//                     }
//                 )
//             } else {
//                 newData.push(row);
//                 this.setState(
//                     {
//                         data: newData,
//                         editingKey: ''
//                     }
//                 )
//             }
//         } catch (errInfo) {
//             console.log('Validate Failed:', errInfo);
//         }
//     };

//     columns = [
//         {
//             title: 'name',
//             dataIndex: 'name',
//             width: '25%',
//             editable: true,
//         },
//         {
//             title: 'age',
//             dataIndex: 'age',
//             width: '15%',
//             editable: true,
//         },
//         {
//             title: 'address',
//             dataIndex: 'address',
//             width: '40%',
//             editable: true,
//         },
//         {
//             title: 'operation',
//             dataIndex: 'operation',
//             render: (_, record) => {
//                 const editable = this.isEditing(record);
//                 return editable ? (
//                     <span>
//                         <a
//                             href="javascript:;"
//                             onClick={() => this.save(record.key)}
//                             style={{
//                                 marginRight: 8,
//                             }}
//                         >
//                             Save
//             </a>
//                         <Popconfirm title="Sure to cancel?" onConfirm={this.cancel}>
//                             <a>Cancel</a>
//                         </Popconfirm>
//                     </span>
//                 ) : (
//                     <Typography.Link disabled={this.state.editingKey !== ''} onClick={() => this.edit(record)}>
//                         Edit
//                     </Typography.Link>
//                 );
//             },
//         },
//     ];
//     mergedColumns = this.columns.map((col) => {
//         if (!col.editable) {
//             return col;
//         }

//         return {
//             ...col,
//             onCell: (record) => ({
//                 record,
//                 inputType: col.dataIndex === 'age' ? 'number' : 'text',
//                 dataIndex: col.dataIndex,
//                 title: col.title,
//                 editing: this.isEditing(record),
//             }),
//         };
//     });
//     render() {
//         return (
//             <Form form={form} component={false}>
//                 <Table
//                     components={{
//                         body: {
//                             cell: EditableCell,
//                         },
//                     }}
//                     bordered
//                     dataSource={this.state.data}
//                     columns={this.mergedColumns}
//                     rowClassName="editable-row"
//                     pagination={{
//                         onChange: this.cancel,
//                     }}
//                 />
//             </Form>
//         );
//     }
// };

// export default EditableTable;